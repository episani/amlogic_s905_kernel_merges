/*
 * Copyright 2008 Extreme Engineering Solutions, Inc.
 *
 * SPDX-License-Identifier:	GPL-2.0+
 */

#ifndef __FSL_8XXX_MISC_H___
#define __FSL_8XXX_MISC_H___

uint get_board_derivative(void);

#endif /* __FSL_8XXX_MISC_H__ */
